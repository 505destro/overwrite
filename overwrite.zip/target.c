#include <stdio.h>

int main() {
    printf("Hello i am a target. Please help me\n");

    return 0;
}